package io.ahnlab.abcmpc

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class KeyIdResponse(
    val result: String
)

@Serializable
data class GenerateShareResponse(
    @SerialName("key_id")
    val keyId: String,
    
    @SerialName("encrypted_share")
    val encryptedShare: String,
    
    @SerialName("secret_store")
    val secretStore: String,
    
    val curve: String
)

typealias RecoverShareResponse = GenerateShareResponse

@Serializable
data class ValidatePasswordAndSecretStoreResponse(
    val result: Boolean,
)

typealias ValidateShareAndSecretStoreResponse = ValidatePasswordAndSecretStoreResponse

@Serializable
data class PublicKeyResponse(
    val result: String
)

@Serializable
data class SignResponse(
    val signature: String,
)