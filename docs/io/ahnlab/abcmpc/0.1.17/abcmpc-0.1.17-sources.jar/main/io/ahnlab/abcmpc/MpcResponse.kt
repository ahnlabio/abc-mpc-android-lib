package io.ahnlab.abcmpc

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class KeyIdResponse(
    val result: String
)

@Serializable
data class GenerateShareResponse(
    @SerialName("key_id")
    val keyId: String,

    @SerialName("encrypted_share")
    val encryptedShare: String,

    @SerialName("secret_store")
    val secretStore: String,

    val curve: String,

    @SerialName("deprecation_warning")
    val deprecationWarning: String? = null,
)

typealias RecoverShareResponse = GenerateShareResponse

@Serializable
data class ValidatePasswordAndSecretStoreResponse(
    val result: Boolean,

    @SerialName("deprecation_warning")
    val deprecationWarning: String? = null,
)

typealias ValidateShareAndSecretStoreResponse = ValidatePasswordAndSecretStoreResponse

@Serializable
data class PublicKeyResponse(
    val result: String,

    @SerialName("deprecation_warning")
    val deprecationWarning: String? = null,
)

@Serializable
data class SignResponse(
    val signature: String,

    @SerialName("deprecation_warning")
    val deprecationWarning: String? = null,
)

/**
 * Secret store 포맷 버전.
 * - V2 (default): password 와 secret_store 둘 다 필요 (보안 강화).
 * - V1 (deprecated): secret_store 만으로 복호화 가능. 하위 호환 용도로 남겨두며 향후 제거 예정.
 */
enum class SecretStoreVersion(val raw: Int) {
    V1(1),
    V2(2),
}