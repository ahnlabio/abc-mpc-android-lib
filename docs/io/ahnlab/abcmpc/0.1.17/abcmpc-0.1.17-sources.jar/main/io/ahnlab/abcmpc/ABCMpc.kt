package io.ahnlab.abcmpc

import org.json.JSONObject
import org.json.JSONArray

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

sealed class MpcError(override val message: String) : Exception(message) {
    object InvalidJsonFormat : MpcError("JSON 형식이 유효하지 않습니다.")
    object NoData : MpcError("응답에 데이터가 없습니다.")
    class DecodingError(val originalError: Throwable, val jsonString: String = "") : 
        MpcError("디코딩 오류: ${originalError.localizedMessage}\nJSON 데이터: $jsonString")
    class OperationFailed(val errorDetail: String) : 
        MpcError("오류가 발생하였습니다: $errorDetail")
    
    // 필요한 경우 description 속성 추가 (이미 message로 접근 가능하지만 Swift 코드와 일관성을 위해)
    val description: String
        get() = message
}

// JSON 설정
private val json = Json {
    ignoreUnknownKeys = true  // 모델에 없는 키는 무시
    isLenient = true          // 따옴표 없는 키 등 허용
    coerceInputValues = true  // 기본값이 있는 경우 누락된 필드 처리
}

class ABCMpc private constructor() {
    companion object {
        init {
            System.loadLibrary("abc_mpc_core_mobile")
        }

        // 싱글턴 인스턴스
        @Volatile
        private var instance: ABCMpc? = null
        
        // 인스턴스 가져오는 메소드
        fun getInstance(): ABCMpc {
            return instance ?: synchronized(this) {
                instance ?: ABCMpc().also { instance = it }
            }
        }
    }

    suspend fun generate_key_id(): Result<KeyIdResponse> = withContext(Dispatchers.IO) {
        val jsonResult = crandomKeyId()
        try {
            val response = json.decodeFromString<KeyIdResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun generate_share(
        node_1_url:String,
        node_2_url:String,
        auth_token:String,
        mpc_token:String,
        key_id:String,
        curve:String,
        password: String? = null,
        version: SecretStoreVersion = SecretStoreVersion.V2,
    ): Result<GenerateShareResponse> = withContext(Dispatchers.IO) {
        val jsonResult = crandomGenrerateShare(node_1_url, node_2_url, auth_token, mpc_token, key_id, curve, password, version.raw)
        try {
            val response = json.decodeFromString<GenerateShareResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun recover_share(
        node_1_url:String,
        node_2_url:String,
        auth_token: String,
        mpc_token: String,
        target_key_id: String,
        source_key_id: String,
        curve: String,
        password: String? = null,
        version: SecretStoreVersion = SecretStoreVersion.V2,
    ): Result<RecoverShareResponse> = withContext(Dispatchers.IO) {
        val jsonResult = crandomRecoverShare(node_1_url, node_2_url, auth_token, mpc_token, target_key_id, source_key_id, curve, password, version.raw)
        try {
            val response = json.decodeFromString<RecoverShareResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun validate_password_and_secret_store(
        password: String?,
        secret_store: String
    ): Result<ValidatePasswordAndSecretStoreResponse> = withContext(Dispatchers.IO) {
        val jsonResult = cvalidatePasswordAndSecretStore(password, secret_store)
        try {
            val response = json.decodeFromString<ValidatePasswordAndSecretStoreResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun validate_share_and_secret_store(
        encrypted_share: String,
        secret_store: String,
        password: String? = null,
    ): Result<ValidateShareAndSecretStoreResponse> = withContext(Dispatchers.IO) {
        val jsonResult = cvalidateShareAndSecretStore(encrypted_share, secret_store, password)
        try {
            val response = json.decodeFromString<ValidateShareAndSecretStoreResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun public_key(
        key_id: String,
        encrypted_share: String,
        secret_store: String,
        curve: String,
        password: String? = null,
    ): Result<PublicKeyResponse> = withContext(Dispatchers.IO) {
        val jsonResult = cpublicKey(key_id, encrypted_share, secret_store, curve, password)
        try {
            val response = json.decodeFromString<PublicKeyResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun sign(
        node_1_url:String,
        auth_token:String,
        mpc_token:String,
        key_id:String,
        encrypted_share:String,
        secret_store:String,
        curve:String,
        message:String,
        password: String? = null,
    ): Result<SignResponse> = withContext(Dispatchers.IO) {
        val jsonResult = csign(node_1_url, auth_token, mpc_token, key_id, encrypted_share, secret_store, curve, message, password)
        try {
            val response = json.decodeFromString<SignResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun sign_mta(
        node_1_url: String,
        auth_token: String,
        mpc_token: String,
        key_id: String,
        encrypted_share: String,
        secret_store: String,
        message: String,
        password: String? = null,
    ): Result<SignResponse> = withContext(Dispatchers.IO) {
        val jsonResult = csignMta(node_1_url, auth_token, mpc_token, key_id, encrypted_share, secret_store, message, password)
        try {
            val response = json.decodeFromString<SignResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun sign_mta_derived(
        node_1_url: String,
        auth_token: String,
        mpc_token: String,
        key_id: String,
        encrypted_share: String,
        secret_store: String,
        message: String,
        chain_code: String,
        path: String,
        password: String? = null,
    ): Result<SignResponse> = withContext(Dispatchers.IO) {
        val jsonResult = csignMtaDerived(node_1_url, auth_token, mpc_token, key_id, encrypted_share, secret_store, message, chain_code, path, password)
        try {
            val response = json.decodeFromString<SignResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun sign_with_chain_code(
        node_1_url: String,
        auth_token: String,
        mpc_token: String,
        key_id: String,
        encrypted_share: String,
        secret_store: String,
        curve: String,
        message: String,
        chain_code: String,
        path: String,
        password: String? = null,
    ): Result<SignResponse> = withContext(Dispatchers.IO) {
        val jsonResult = csignWithChainCode(node_1_url, auth_token, mpc_token, key_id, encrypted_share, secret_store, curve, message, chain_code, path, password)
        try {
            val response = json.decodeFromString<SignResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun public_key_with_chain_code(
        key_id: String,
        encrypted_share: String,
        secret_store: String,
        curve: String,
        chain_code: String,
        path: String,
        password: String? = null,
    ): Result<PublicKeyResponse> = withContext(Dispatchers.IO) {
        val jsonResult = cpublicKeyWithChainCode(key_id, encrypted_share, secret_store, curve, chain_code, path, password)
        try {
            val response = json.decodeFromString<PublicKeyResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    suspend fun import_private_key_to_share(
        node_1_url: String,
        node_2_url: String,
        auth_token: String,
        mpc_token: String,
        private_key: String,
        password: String? = null,
        version: SecretStoreVersion = SecretStoreVersion.V2,
    ): Result<GenerateShareResponse> = withContext(Dispatchers.IO) {
        val jsonResult = cimportPrivateKeyToShare(node_1_url, node_2_url, auth_token, mpc_token, private_key, password, version.raw)
        try {
            val response = json.decodeFromString<GenerateShareResponse>(jsonResult)
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(MpcError.DecodingError(e, jsonResult))
        }
    }

    /**
     * secp256k1 signature 검증. signature 는 r||s 합쳐진 hex(128자), public_key 는 압축(66자)/비압축(130자) hex.
     */
    suspend fun verify_secp256k1(
        message: String,
        signature: String,
        public_key: String,
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(cverifySecp256k1(message, signature, public_key)) }
        catch (e: Exception) { Result.failure(e) }
    }

    /**
     * ed25519 signature 검증. signature 는 r||s 합쳐진 hex(128자), public_key 는 32B hex(64자).
     */
    suspend fun verify_ed25519(
        message: String,
        signature: String,
        public_key: String,
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try { Result.success(cverifyEd25519(message, signature, public_key)) }
        catch (e: Exception) { Result.failure(e) }
    }

    private external fun crandomKeyId(): String
    private external fun crandomGenrerateShare(node_1_url: String, node_2_url: String, auth_token: String, mpc_token: String, key_id: String, curve: String, password: String?, version: Int): String
    private external fun crandomRecoverShare(node_1_url: String, node_2_url: String, auth_token: String, mpc_token: String, target_key_id: String, source_key_id: String, curve: String, password: String?, version: Int): String
    private external fun cvalidatePasswordAndSecretStore(password: String?, secret_store: String): String
    private external fun cvalidateShareAndSecretStore(encrypted_share: String, secret_store: String, password: String?): String
    private external fun cpublicKey(key_id: String, encrypted_share: String, secret_store: String, curve: String, password: String?): String
    private external fun csign(node_1_url: String, auth_token: String, mpc_token: String, key_id: String, encrypted_share: String, secret_store: String, curve: String, message: String, password: String?): String
    private external fun csignMta(node_1_url: String, auth_token: String, mpc_token: String, key_id: String, encrypted_share: String, secret_store: String, message: String, password: String?): String
    private external fun csignMtaDerived(node_1_url: String, auth_token: String, mpc_token: String, key_id: String, encrypted_share: String, secret_store: String, message: String, chain_code: String, path: String, password: String?): String
    private external fun csignWithChainCode(node_1_url: String, auth_token: String, mpc_token: String, key_id: String, encrypted_share: String, secret_store: String, curve: String, message: String, chain_code: String, path: String, password: String?): String
    private external fun cpublicKeyWithChainCode(key_id: String, encrypted_share: String, secret_store: String, curve: String, chain_code: String, path: String, password: String?): String
    private external fun cimportPrivateKeyToShare(node_1_url: String, node_2_url: String, auth_token: String, mpc_token: String, private_key: String, password: String?, version: Int): String
    private external fun cverifySecp256k1(message: String, signature: String, public_key: String): Boolean
    private external fun cverifyEd25519(message: String, signature: String, public_key: String): Boolean

}

